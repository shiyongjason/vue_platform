// import commonTable from '../packages/zfTable/common-table.vue'
// import zfLayout from './zfLayout'


// const components = [
//     commonTable,
//     zfLayout
// ]
// const install = function (Vue) {
//     components.forEach(component => {
//         // 组件name
//         Vue.component(component.name, component)
//     })

//     if (typeof window !== 'undefined' && window.Vue) {
//         install(window.Vue)
//     }
// }
// export default install
