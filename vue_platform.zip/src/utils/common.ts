/**
 * @Description 防抖
 * @param wait 等待时间
 */
